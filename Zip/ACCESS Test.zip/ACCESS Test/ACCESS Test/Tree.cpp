
#include "Tree.h"

Tree::Tree(vector<string> m, int posX)
{
	map = m;
	int maxSize = pow(2, (map.size() + 1) / 2) - 1;
	tree.resize(maxSize, 0);
	treeExist.resize(maxSize, false);
	int last = map.size() - 1;
	for (int i = 0; i < map[last].size(); i++)
	{
		if (map[last][i] != ' ')
		{
			break;
		}
	}

	int lineLength = 2 * map.size() - 1;
	int initPosX = posX - map.size() + 1;

	for (int i = 0; i < map.size(); i++)
	{
		map[i] = map[i].substr(initPosX, lineLength);
		map[i].resize(lineLength, ' ');
	}
	posX = map.size();
	//BuildTree(posX, 0, 0, 0);
}

Tree::~Tree()
{
}

void Tree::DisplayTree() {
	for (int i = 0; i < map.size(); i++)
	{
		cout << map[i] << endl;
	}
}
void Tree::merge(Tree tree1) {
	if (tree.size() < tree1.tree.size())
	{
		tree.resize(tree1.tree.size());
		treeExist.resize(tree1.tree.size(), false);
	}
	for (int i = 0; i < tree.size(); i++)
	{
		tree[i] += tree1.tree[i];
		treeExist[i] = treeExist[i] | tree1.treeExist[i];
	}
	if (map.size() < tree1.map.size())
	{
		map.resize(tree1.map.size());
	}
	for (int i = 0; i < map.size(); i++)
	{
		if (map[i].size() < tree1.map[i].size())
		{
			map[i].resize(tree1.map[i].size(), ' ');
		}
		for (int j = 0; j < map[i].size(); j++)
		{
			if (tree1.map[i][j] != ' ')
			{
				if (map[i][j] == ' ')
				{
					map[i][j] = tree1.map[i][j];

				}
				else if (map[i][j] != '/' && map[i][j] != '\\')
				{
					string tmp = to_string((tree1.map[i][j] - '0') + (map[i][j] - '0'));
					for (int k = 0; k < tmp.size(); k++)
					{
						if (j + k > map[i].size())
						{
							map[i].push_back(tmp[k]);
						}
						else
						{
							map[i][j + k] = tmp[k];
						}
					}
				}
			}

		}
	}
}


/*void BuildTree(int posX, int posY, int indexX, int indexY) {
	int offset = pow(2, indexY) - 1;
	treeExist[offset + indexX] = true;
	tree[offset + indexX] += (map[posY][posX] - '0');
	if (posY + 1 < map.size())
	{
		if (posX > 0 && map[posY + 1][posX - 1] == '/')
		{
			BuildTree(posX - 2, posY + 2, indexX * 2, indexY + 1);
		}
		if (posX < map[posY + 1].size() && map[posY + 1][posX + 1] == '\\')
		{
			BuildTree(posX + 2, posY + 2, indexX * 2 + 1, indexY + 1);
		}
	}
}*/