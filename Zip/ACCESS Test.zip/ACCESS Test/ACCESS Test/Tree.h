#pragma once
#include <vector>
#include <iostream>
#include<string>

using namespace std;

class Tree
{
public:
	Tree(vector<string> m, int posX);
	~Tree();
	void DisplayTree();
	void merge(Tree tree1);
private:
	vector<string> map;
	vector<int>tree;
	vector<bool>treeExist;


};

